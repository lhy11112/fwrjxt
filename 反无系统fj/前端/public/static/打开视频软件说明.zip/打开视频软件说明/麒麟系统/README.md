# voko-screen 浏览器调用配置指南（银河麒麟 arm64 专用）

## 📋 前置条件
1.  已成功安装 voko-screen 录屏软件（通过 `sudo dpkg -i vokoscreen_2.5.0-4_arm64.deb` 安装）
2.  银河麒麟 V10 及以上版本系统
3.  系统自带麒麟浏览器（推荐）

---

## 🚀 快速开始

### 步骤1：配置自定义协议（仅需执行一次）
1.  打开终端，进入文件所在目录
    ```bash
    cd /path/to/your/files
    ```
2.  给脚本赋予执行权限
    ```bash
    chmod +x install-protocol.sh
    ```
3.  执行脚本
    ```bash
    ./install-protocol.sh
    ```
4.  看到「配置完成」提示，说明协议配置成功

### 步骤2：浏览器测试调用
1.  找到 `test-browser.html` 文件
2.  右键 → 打开方式 → 选择「麒麟浏览器」
3.  点击页面上的「启动 Voko 录屏」按钮
4.  浏览器弹出提示时，选择「允许打开」，即可启动录屏软件
---

## 🔧 技术原理
### 自定义协议实现流程
1.  **协议注册**：通过 `.desktop` 文件注册 `voko://` 自定义协议
2.  **系统绑定**：`update-desktop-database` 刷新桌面数据库，`xdg-mime` 绑定协议与软件
3.  **浏览器调用**：网页通过 `a href="voko://open"` 触发协议，系统调用对应软件

### 关键命令说明
| 命令 | 作用 |
|------|------|
| `update-desktop-database ~/.local/share/applications` | 刷新用户级桌面应用数据库，使新配置生效 |
| `xdg-mime default voko.desktop x-scheme-handler/voko` | 将 `voko://` 协议绑定到指定软件 |

---

## ❌ 常见问题排查

### 1. 点击链接无反应
- 检查软件路径：执行 `which voko-screen`，确认 `.desktop` 文件中的 `Exec=` 路径一致
- 重新执行 `install-protocol.sh` 脚本，确保配置正确
- 关闭浏览器无痕模式，使用系统默认麒麟浏览器

### 2. 终端提示「命令未找到」
- 确认 voko-screen 已安装：执行 `dpkg -l | grep voko-screen`
- 重新安装 `.deb` 包：`sudo dpkg -i vokoscreen_2.5.0-4_arm64.deb`

### 3. 桌面图标无法启动
- 右键图标 → 选择「允许启动」
- 检查图标执行权限：`ls -l ~/Desktop/Voko录屏.desktop`，确保有 `x` 权限

---

## 📄 文件说明
| 文件名 | 用途 |
|--------|------|
| `install-protocol.sh` | 一键配置自定义协议，实现浏览器调用 |
| `create-desktop.sh` | 生成桌面快捷方式，方便快速启动 |
| `test-browser.html` | 浏览器调用测试页面，验证功能是否正常 |
| `README.md` | 本使用说明文档 |

---

## 📞 技术支持
如遇问题，请检查：
1.  系统版本是否为银河麒麟 V10+
2.  软件架构是否为 arm64（与安装包一致）
3.  浏览器是否为系统自带麒麟浏览器
