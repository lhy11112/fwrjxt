#!/bin/bash
# vokoscreen 自定义协议配置脚本（银河麒麟 arm64 专用）
# 执行此脚本后，浏览器可通过 voko:// 协议调用录屏软件

echo "===== 开始配置 vokoscreen 自定义协议 ====="

# 1. 检查软件是否安装
VOKO_PATH=$(which vokoscreen)

if [  -z "$VOKO_PATH"  ]   ; then
    echo "❌ 错误：未找到 vokoscreen 软件，请先安装 .deb 包"
    exit 1
fi

# 获取软件绝对路径
echo "✅ 检测到 vokoscreen 路径	：$VOKO_PATH"

# 2. 创建配置目录
mkdir -p ~/.local/share/applications
echo "✅ 配置目录已创建"

# 3. 写入协议配置文件
cat > ~/.local/share/applications/voko.desktop << EOF
[Desktop Entry]
Name=Voko录屏
Exec=$VOKO_PATH %u
Type=Application
NoDisplay=true
MimeType=x-scheme-handler/voko;
EOF
echo "✅ 协议配置文件已写入"

# 4. 更新桌面数据库
update-desktop-database ~/.local/share/applications
echo "✅ 桌面数据库已更新"

# 5. 绑定协议默认打开方式
xdg-mime default voko.desktop x-scheme-handler/voko
echo "✅ 协议绑定完成"



DESKTOP_PATH="$HOME/桌面"
# 写入桌面快捷方式
sudo cat > "$DESKTOP_PATH"/Voko录屏.desktop << EOF
[Desktop Entry]
Name=Voko录屏
Exec=$VOKO_PATH
Icon=video-capture
Terminal=false
Type=Application
Categories=Utility;
EOF

# 赋予执行权限
sudo  chmod +x  "$DESKTOP_PATH"/Voko录屏.desktop

echo "✅ 桌面快捷方式已生成！"
# echo "请右键桌面图标，选择「允许启动」即可使用"

echo "===== 配置完成！浏览器可通过 voko:// 调用软件 ====="
echo "测试方法：打开 test-browser.html，点击链接即可启动"
